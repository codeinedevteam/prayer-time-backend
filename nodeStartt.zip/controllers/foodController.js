let Controller = require('./controller');
const { validationResult } = require('express-validator');

const Food = require('models/food');
class FoodController extends Controller {
	async getAllFoods(req, res, next) {
		try {
			let Foods = await Food.find({});
			res.status(200).json({
				data: Foods,
				success: true
			});
		} catch (err) {
			next(err);
		}
	}
	async seeOneFoodasync(req, res, next) {
		try {
			let food = await Food.findById(req.params.id);
			res.status(200).json({
				data: food,
				success: true
			});
		} catch (err) {
			next(err);
		}
	}
	async createFood(req, res,next) {
		console.log(req.body)
		try {
			const errors = validationResult(req);
			console.log(errors)
				// if (!errors.isEmpty()) {
				// 	return res.status(422).json({ errors: errors.array() });
				// }
			
			let newFood = new Food({
				name: req.body.name,
				desc: req.body.desc,
				kind: req.body.kind,
				barCode:req.body.barCode
			});
			if(req.file){
				newFood.img = req.file.path.substring(6)
			}
			await newFood.save();
			res.json({
				data: 'add user suc',
				success: true
			});
		} catch (err) {
			next(err);
		}
	}
	async editFood(req, res,next) {
		try {
			await Food.updateOne({ _id: req.params.id }, { $set: req.body });
			res.json({
				data: 'update user suc',
				success: true
			});
		} catch (err) {
			next(err);
		}
	}
	async deleteFood(req, res,next) {
		console.log(req.params.id)
		try {
			await Food.deleteOne({ _id: req.params.id });
			res.json({
				data: 'delete user suc',
				success: true
			});
		} catch (err) {
			next(err);
		}
	}
}

module.exports = new FoodController();
