let Controller = require('./controller');
const { validationResult } = require('express-validator');
const passport = require('passport');
const admin = require('../models/admin');

class AuthController extends Controller {
	async LoginForm(req, res, next) {
		try {
			res.send('LoginForm');
		} catch (err) {
			next(err);
		}
	}
	async Login(req, res, next) {
		try {
			console.log('login');
			passport.authenticate('local.login', (err, admin) => {
				console.log('admin');
				if (!admin) return res.redirect('/');
				req.logIn(admin, (err) => {
					return res.redirect('/foods');
				});
			})(req, res, next);
		} catch (err) {
			next(err);
		}
	}
}

module.exports = new AuthController();
