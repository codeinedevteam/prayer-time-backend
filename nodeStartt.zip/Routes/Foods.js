const express = require('express');
const router = express.Router();

const FoodController = require('controllers/foodController');
const FoodValidator = require('validators/foodValidator');
const upload = require('../upload/uploadImg');

router.get('/', FoodController.getAllFoods);
router.get('/:id', FoodController.seeOneFoodasync);

router.post('/', FoodValidator.handle(), upload.single('img'),(req,res,next)=>{
    if(!req.file){
        req.body.img= null
    }else{
        req.body.img=  req.file.filename
    }
    next()
},FoodController.createFood);

router.put('/:id', FoodController.editFood);

router.delete('/:id', FoodController.deleteFood);

module.exports = router;
