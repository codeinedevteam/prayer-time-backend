const express = require('express');
const router = express.Router();

const AuthController = require('controllers/authController');
const authValidator = require('validators/authValidator');

router.get('/login', AuthController.LoginForm);


router.post('/login', AuthController.Login);

module.exports = router;
