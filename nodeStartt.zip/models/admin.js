const mongoose = require('mongoose')
const Schema=mongoose.Schema

const admin= new Schema({
    usernmae:{type :String, required:true,default:"admin"},
    password:{ type :String,required:true ,default:"admin"},


})


module.exports = mongoose.model("Admin",admin,"Admin")