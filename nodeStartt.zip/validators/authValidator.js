const Validator = require('./validator');
const { check } = require('express-validator');

class FoodValidator extends Validator {
	handle() {
		return [ check('name', 'format').isString(), check('desc', 'min').isLength({ min: 2 }) ];
	}
}

module.exports = new FoodValidator;
