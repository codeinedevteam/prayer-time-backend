const passport = require('passport');
const localStrategy = require('passport-local').Strategy;

const Admin = require('../models/admin');

passport.serializeUser((admin, done) => {
	done(null, admin.id);
});

passport.deserializeUser(async(id, done) => {
	let admin = await Admin.findById(id);
	if (admin) {
		done(null, admin);
	}
});

passport.use(
	'local.login',
	new localStrategy(
		{
			usernameField: 'username',
			passwordField: 'password',
			passReqToCallback: true
		},
		async (req, usename, password, done) => {
		try {
            let admin = await Admin.findOne({ username: req.body.username });
			if (!admin || admin.password != req.body.password) {
                return done(null,false,res.send("نام کاربری اشتباه است"))
			}
            done(null,admin)
        } catch (error) {
           return done(error,false,{message:error})
            
        }
		}
	)
);
