module.exports=[
    {
        id:1 ,
        first_name:"mahdi",
        email:"mahdi@gmail.com",
        password:"123456"

    },
    {
        id:2,
        first_name:"mojib",
        email:"mahdi@gmail.com",
        password:"123456"

    },
    {
        id:3,
        first_name:"ali",
        email:"mahdi@gmail.com",
        password:"123456"

    },
    {
        id:4,
        first_name:"ahmad",
        email:"mahdi@gmail.com",
        password:"123456"

    },
    {
        id:5,
        first_name:"hossein",
        email:"mahdi@gmail.com",
        password:"123456"

    }
]